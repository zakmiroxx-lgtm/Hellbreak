#pragma once

#include <SDL.h>

#include "World/Map.h"
#include "World/Player.h"

class Renderer
{
public:
    static constexpr int WIDTH = 960;
    static constexpr int HEIGHT = 600;

    explicit Renderer(SDL_Renderer* renderer);

    void render(
        const Map& map,
        const Player& player
    );

private:
    void renderWorld(
        const Map& map,
        const Player& player
    );

    void renderMinimap(
        const Map& map,
        const Player& player
    );

    void renderCrosshair();

    SDL_Renderer* m_renderer = nullptr;
};
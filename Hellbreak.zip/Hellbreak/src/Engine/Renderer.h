#pragma once

#include <SDL.h>

#include <vector>

#include "../World/Map.h"
#include "../World/Player.h"
#include "../World/Enemy.h"

class Renderer
{
public:
    static constexpr int WIDTH = 960;
    static constexpr int HEIGHT = 600;

    explicit Renderer(SDL_Renderer* renderer);

    void render(
        const Map& map,
        const Player& player,
        const std::vector<Enemy>& enemies,
        bool gameOver,
        bool victory
    );

private:
    void renderWorld(
        const Map& map,
        const Player& player
    );

    void renderEnemies(
        const Player& player,
        const std::vector<Enemy>& enemies
    );

    void renderMinimap(
        const Map& map,
        const Player& player,
        const std::vector<Enemy>& enemies
    );

    void renderWeapon(
        const Player& player
    );

    void renderHUD(
        const Player& player
    );

    void renderOverlay(
        bool gameOver,
        bool victory
    );

    SDL_Renderer* m_renderer = nullptr;

    std::vector<double> m_depthBuffer;
};
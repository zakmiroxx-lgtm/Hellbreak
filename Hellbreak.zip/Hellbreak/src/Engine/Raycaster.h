#pragma once

#include "World/Map.h"

struct RayHit
{
    bool hit = false;

    double distance = 0.0;
    double textureX = 0.0;

    int wallType = 0;
    int side = 0;

    int mapX = 0;
    int mapY = 0;
};

class Raycaster
{
public:
    static RayHit cast(
        const Map& map,
        double originX,
        double originY,
        double directionX,
        double directionY
    );
};
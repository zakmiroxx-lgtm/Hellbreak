#include "Renderer.h"
#include "Raycaster.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

namespace
{
    constexpr double FOV = 1.0471975512;
    constexpr double PI = 3.14159265358979323846;

    Uint8 color(double value)
    {
        return static_cast<Uint8>(
            std::clamp(value, 0.0, 255.0)
        );
    }

    void fillRect(
        SDL_Renderer* renderer,
        int x,
        int y,
        int w,
        int h,
        Uint8 r,
        Uint8 g,
        Uint8 b,
        Uint8 a = 255
    )
    {
        SDL_SetRenderDrawColor(renderer, r, g, b, a);

        SDL_Rect rect{x, y, w, h};

        SDL_RenderFillRect(renderer, &rect);
    }
}

Renderer::Renderer(SDL_Renderer* renderer)
    : m_renderer(renderer),
      m_depthBuffer(WIDTH, 1000.0)
{
}

void Renderer::render(
    const Map& map,
    const Player& player,
    const std::vector<Enemy>& enemies,
    bool gameOver,
    bool victory
)
{
    SDL_SetRenderDrawBlendMode(
        m_renderer,
        SDL_BLENDMODE_BLEND
    );

    SDL_SetRenderDrawColor(
        m_renderer,
        0, 0, 0, 255
    );

    SDL_RenderClear(m_renderer);

    renderWorld(map, player);
    renderEnemies(player, enemies);
    renderWeapon(player);
    renderHUD(player);
    renderMinimap(map, player, enemies);
    renderOverlay(gameOver, victory);

    SDL_RenderPresent(m_renderer);
}

void Renderer::renderWorld(
    const Map& map,
    const Player& player
)
{
    fillRect(
        m_renderer,
        0, 0,
        WIDTH, HEIGHT / 2,
        28, 31, 45
    );

    fillRect(
        m_renderer,
        0, HEIGHT / 2,
        WIDTH, HEIGHT / 2,
        48, 42, 41
    );

    const double dirX = std::cos(player.angle);
    const double dirY = std::sin(player.angle);

    const double planeLength = std::tan(FOV / 2.0);

    const double planeX = -dirY * planeLength;
    const double planeY = dirX * planeLength;

    for (int x = 0; x < WIDTH; ++x)
    {
        const double cameraX =
            2.0 * x / WIDTH - 1.0;

        const double rayX =
            dirX + planeX * cameraX;

        const double rayY =
            dirY + planeY * cameraX;

        const RayHit hit = Raycaster::cast(
            map,
            player.x,
            player.y,
            rayX,
            rayY
        );

        if (!hit.hit)
        {
            m_depthBuffer[x] = 1000.0;
            continue;
        }

        const double distance =
            std::max(hit.distance, 0.05);

        m_depthBuffer[x] = distance;

        const int wallHeight =
            static_cast<int>(HEIGHT / distance);

        const int start =
            std::max(
                0,
                HEIGHT / 2 - wallHeight / 2
            );

        const int end =
            std::min(
                HEIGHT - 1,
                HEIGHT / 2 + wallHeight / 2
            );

        double red = 155;
        double green = 72;
        double blue = 65;

        if (hit.wallType == 2)
        {
            red = 75;
            green = 105;
            blue = 155;
        }
        else if (hit.wallType == 3)
        {
            red = 90;
            green = 145;
            blue = 105;
        }

        const int textureColumn =
            static_cast<int>(hit.textureX * 8.0);

        const double textureShade =
            textureColumn % 2 == 0 ? 1.0 : 0.78;

        const double sideShade =
            hit.side == 1 ? 0.72 : 1.0;

        const double fog =
            1.0 / (1.0 + distance * 0.08);

        const double shade =
            textureShade * sideShade * fog;

        red *= shade;
        green *= shade;
        blue *= shade;

        SDL_SetRenderDrawColor(
            m_renderer,
            color(red),
            color(green),
            color(blue),
            255
        );

        SDL_RenderDrawLine(
            m_renderer,
            x,
            start,
            x,
            end
        );

        for (int row = 1; row < 8; ++row)
        {
            const int y =
                HEIGHT / 2 -
                wallHeight / 2 +
                wallHeight * row / 8;

            if (y < start || y > end)
                continue;

            SDL_SetRenderDrawColor(
                m_renderer,
                color(red * 0.5),
                color(green * 0.5),
                color(blue * 0.5),
                255
            );

            SDL_RenderDrawPoint(
                m_renderer,
                x,
                y
            );
        }
    }
}

void Renderer::renderEnemies(
    const Player& player,
    const std::vector<Enemy>& enemies
)
{
    std::vector<const Enemy*> sorted;

    for (const Enemy& enemy : enemies)
    {
        if (enemy.isAlive())
        {
            sorted.push_back(&enemy);
        }
    }

    std::sort(
        sorted.begin(),
        sorted.end(),
        [&player](const Enemy* a, const Enemy* b)
        {
            const double da = std::hypot(
                a->x() - player.x,
                a->y() - player.y
            );

            const double db = std::hypot(
                b->x() - player.x,
                b->y() - player.y
            );

            return da > db;
        }
    );

    const double dirX = std::cos(player.angle);
    const double dirY = std::sin(player.angle);

    const double planeLength = std::tan(FOV / 2.0);

    const double planeX = -dirY * planeLength;
    const double planeY = dirX * planeLength;

    for (const Enemy* enemy : sorted)
    {
        const double spriteX =
            enemy->x() - player.x;

        const double spriteY =
            enemy->y() - player.y;

        const double determinant =
            planeX * dirY - dirX * planeY;

        if (std::abs(determinant) < 0.0001)
            continue;

        const double inverse = 1.0 / determinant;

        const double transformX =
            inverse *
            (dirY * spriteX - dirX * spriteY);

        const double transformY =
            inverse *
            (-planeY * spriteX + planeX * spriteY);

        if (transformY <= 0.1)
            continue;

        const int screenX =
            static_cast<int>(
                WIDTH / 2 *
                (1.0 + transformX / transformY)
            );

        const int spriteHeight =
            std::abs(
                static_cast<int>(
                    HEIGHT / transformY
                )
            );

        const int spriteWidth =
            spriteHeight / 2;

        if (spriteWidth <= 0)
            continue;

        const int startY =
            HEIGHT / 2 - spriteHeight / 2;

        const int endY =
            HEIGHT / 2 + spriteHeight / 2;

        const int startX =
            screenX - spriteWidth / 2;

        const int endX =
            screenX + spriteWidth / 2;

        for (int stripe = startX; stripe < endX; ++stripe)
        {
            if (stripe < 0 || stripe >= WIDTH)
                continue;

            if (transformY >= m_depthBuffer[stripe])
                continue;

            const double u =
                static_cast<double>(
                    stripe - startX
                ) / spriteWidth;

            if (u < 0.08 || u > 0.92)
                continue;

            SDL_SetRenderDrawColor(
                m_renderer,
                170, 45, 50, 255
            );

            SDL_RenderDrawLine(
                m_renderer,
                stripe,
                std::max(0, startY),
                stripe,
                std::min(HEIGHT - 1, endY)
            );

            if (u > 0.22 && u < 0.78)
            {
                SDL_SetRenderDrawColor(
                    m_renderer,
                    240, 185, 65, 255
                );

                const int eyeY =
                    startY + spriteHeight / 3;

                SDL_RenderDrawLine(
                    m_renderer,
                    stripe,
                    eyeY,
                    stripe,
                    eyeY + std::max(2, spriteHeight / 16)
                );
            }
        }
    }
}

void Renderer::renderWeapon(const Player& player)
{
    const int animationOffset =
        static_cast<int>(
            player.weaponAnimation * 180.0
        );

    const int center = WIDTH / 2;

    fillRect(
        m_renderer,
        center - 70,
        HEIGHT - 145 + animationOffset,
        140,
        145,
        72, 77, 88
    );

    fillRect(
        m_renderer,
        center - 42,
        HEIGHT - 195 + animationOffset,
        84,
        110,
        38, 42, 52
    );

    fillRect(
        m_renderer,
        center - 18,
        HEIGHT - 220 + animationOffset,
        36,
        85,
        23, 26, 33
    );

    if (player.weaponAnimation > 0.08)
    {
        fillRect(
            m_renderer,
            center - 35,
            HEIGHT - 260,
            70,
            55,
            255, 185, 55
        );

        fillRect(
            m_renderer,
            center - 15,
            HEIGHT - 280,
            30,
            75,
            255, 230, 120
        );
    }
}

void Renderer::renderHUD(const Player& player)
{
    fillRect(
        m_renderer,
        0,
        HEIGHT - 65,
        WIDTH,
        65,
        14, 17, 24
    );

    fillRect(
        m_renderer,
        25,
        HEIGHT - 42,
        204,
        24,
        70, 25, 30
    );

    const int healthWidth =
        std::clamp(player.health, 0, 100) * 2;

    fillRect(
        m_renderer,
        27,
        HEIGHT - 40,
        healthWidth,
        20,
        215, 50, 65
    );

    // Ammo indicator

    const int ammoBars =
        std::min(player.ammo, 20);

    for (int i = 0; i < ammoBars; ++i)
    {
        fillRect(
            m_renderer,
            WIDTH - 30 - i * 12,
            HEIGHT - 42,
            8,
            24,
            220, 180, 65
        );
    }

    // Crosshair

    SDL_SetRenderDrawColor(
        m_renderer,
        225, 230, 220, 255
    );

    const int cx = WIDTH / 2;
    const int cy = HEIGHT / 2;

    SDL_RenderDrawLine(
        m_renderer,
        cx - 10, cy,
        cx - 3, cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx + 3, cy,
        cx + 10, cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx, cy - 10,
        cx, cy - 3
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx, cy + 3,
        cx, cy + 10
    );
}

void Renderer::renderMinimap(
    const Map& map,
    const Player& player,
    const std::vector<Enemy>& enemies
)
{
    constexpr int SCALE = 7;
    constexpr int OFFSET = 15;

    fillRect(
        m_renderer,
        OFFSET - 5,
        OFFSET - 5,
        Map::WIDTH * SCALE + 10,
        Map::HEIGHT * SCALE + 10,
        12, 15, 22, 225
    );

    for (int y = 0; y < Map::HEIGHT; ++y)
    {
        for (int x = 0; x < Map::WIDTH; ++x)
        {
            const bool wall =
                map.tile(x, y) != 0;

            fillRect(
                m_renderer,
                OFFSET + x * SCALE,
                OFFSET + y * SCALE,
                SCALE - 1,
                SCALE - 1,
                wall ? 140 : 35,
                wall ? 70 : 40,
                wall ? 65 : 50
            );
        }
    }

    for (const Enemy& enemy : enemies)
    {
        if (!enemy.isAlive())
            continue;

        fillRect(
            m_renderer,
            OFFSET + static_cast<int>(enemy.x() * SCALE) - 2,
            OFFSET + static_cast<int>(enemy.y() * SCALE) - 2,
            5,
            5,
            240, 55, 65
        );
    }

    fillRect(
        m_renderer,
        OFFSET + static_cast<int>(player.x * SCALE) - 3,
        OFFSET + static_cast<int>(player.y * SCALE) - 3,
        6,
        6,
        75, 240, 140
    );
}

void Renderer::renderOverlay(
    bool gameOver,
    bool victory
)
{
    if (!gameOver && !victory)
        return;

    fillRect(
        m_renderer,
        0, 0,
        WIDTH, HEIGHT,
        gameOver ? 100 : 20,
        gameOver ? 10 : 90,
        gameOver ? 15 : 55,
        180
    );

    fillRect(
        m_renderer,
        WIDTH / 2 - 180,
        HEIGHT / 2 - 45,
        360,
        90,
        15, 18, 25, 240
    );

    fillRect(
        m_renderer,
        WIDTH / 2 - 130,
        HEIGHT / 2 - 6,
        260,
        12,
        victory ? 75 : 220,
        victory ? 230 : 55,
        victory ? 135 : 65
    );
}
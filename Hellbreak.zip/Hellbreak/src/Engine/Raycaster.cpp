Run cmake --build build `
MSBuild version 17.14.60+43b635718 for .NET Framework
  1>Checking Build System
  Generating include/SDL2/SDL.h
  Generating include/SDL2/SDL_assert.h
  Generating include/SDL2/SDL_atomic.h
  Generating include/SDL2/SDL_audio.h
  Generating include/SDL2/SDL_bits.h
  Generating include/SDL2/SDL_blendmode.h
  Generating include/SDL2/SDL_clipboard.h
  Generating include/SDL2/SDL_copying.h
  Generating include/SDL2/SDL_cpuinfo.h
  Generating include/SDL2/SDL_egl.h
  Generating include/SDL2/SDL_endian.h
  Generating include/SDL2/SDL_error.h
  Generating include/SDL2/SDL_events.h
  Generating include/SDL2/SDL_filesystem.h
  Generating include/SDL2/SDL_gamecontroller.h
  Generating include/SDL2/SDL_gesture.h
  Generating include/SDL2/SDL_guid.h
  Generating include/SDL2/SDL_haptic.h
  Generating include/SDL2/SDL_hidapi.h
  Generating include/SDL2/SDL_hints.h
  Generating include/SDL2/SDL_joystick.h
  Generating include/SDL2/SDL_keyboard.h
  Generating include/SDL2/SDL_keycode.h
  Generating include/SDL2/SDL_loadso.h
  Generating include/SDL2/SDL_locale.h
  Generating include/SDL2/SDL_log.h
  Generating include/SDL2/SDL_main.h
  Generating include/SDL2/SDL_messagebox.h
  Generating include/SDL2/SDL_metal.h
  Generating include/SDL2/SDL_misc.h
  Generating include/SDL2/SDL_mouse.h
  Generating include/SDL2/SDL_mutex.h
  Generating include/SDL2/SDL_name.h
  Generating include/SDL2/SDL_opengl.h
  Generating include/SDL2/SDL_opengl_glext.h
  Generating include/SDL2/SDL_opengles.h
  Generating include/SDL2/SDL_opengles2.h
  Generating include/SDL2/SDL_opengles2_gl2.h
  Generating include/SDL2/SDL_opengles2_gl2ext.h
  Generating include/SDL2/SDL_opengles2_gl2platform.h
  Generating include/SDL2/SDL_opengles2_khrplatform.h
  Generating include/SDL2/SDL_pixels.h
  Generating include/SDL2/SDL_platform.h
  Generating include/SDL2/SDL_power.h
  Generating include/SDL2/SDL_quit.h
  Generating include/SDL2/SDL_rect.h
  Generating include/SDL2/SDL_render.h
  Generating include/SDL2/SDL_rwops.h
  Generating include/SDL2/SDL_scancode.h
  Generating include/SDL2/SDL_sensor.h
  Generating include/SDL2/SDL_shape.h
  Generating include/SDL2/SDL_stdinc.h
  Generating include/SDL2/SDL_surface.h
  Generating include/SDL2/SDL_system.h
  Generating include/SDL2/SDL_syswm.h
  Generating include/SDL2/SDL_test.h
  Generating include/SDL2/SDL_test_assert.h
  Generating include/SDL2/SDL_test_common.h
  Generating include/SDL2/SDL_test_compare.h
  Generating include/SDL2/SDL_test_crc32.h
  Generating include/SDL2/SDL_test_font.h
  Generating include/SDL2/SDL_test_fuzzer.h
  Generating include/SDL2/SDL_test_harness.h
  Generating include/SDL2/SDL_test_images.h
  Generating include/SDL2/SDL_test_log.h
  Generating include/SDL2/SDL_test_md5.h
  Generating include/SDL2/SDL_test_memory.h
  Generating include/SDL2/SDL_test_random.h
  Generating include/SDL2/SDL_thread.h
  Generating include/SDL2/SDL_timer.h
  Generating include/SDL2/SDL_touch.h
  Generating include/SDL2/SDL_types.h
  Generating include/SDL2/SDL_version.h
  Generating include/SDL2/SDL_video.h
  Generating include/SDL2/SDL_vulkan.h
  Generating include/SDL2/begin_code.h
  Generating include/SDL2/close_code.h
  Building Custom Rule D:/a/Hellbreak/Hellbreak/build/_deps/sdl2-src/CMakeLists.txt
  Building Custom Rule D:/a/Hellbreak/Hellbreak/build/_deps/sdl2-src/CMakeLists.txt
  Building Custom Rule D:/a/Hellbreak/Hellbreak/build/_deps/sdl2-src/CMakeLists.txt
  SDL_windows_main.c
  SDL.c
  SDL_assert.c
  SDL_dataqueue.c
  SDL_error.c
  SDL_guid.c
  SDL_hints.c
  SDL_list.c
  SDL_log.c
  SDL_utils.c
  SDL_atomic.c
  SDL_spinlock.c
  SDL_audio.c
  SDL_audiocvt.c
  SDL_audiodev.c
  SDL_audiotypecvt.c
  SDL_mixer.c
  SDL_wave.c
  SDL2main.vcxproj -> D:\a\Hellbreak\Hellbreak\build\_deps\sdl2-build\Release\SDL2main.lib
  SDL_cpuinfo.c
  SDL_dynapi.c
  SDL_clipboardevents.c
  SDL_displayevents.c
  SDL_dropevents.c
  SDL_events.c
  SDL_gesture.c
  SDL_keyboard.c
  SDL_keysym_to_scancode.c
  SDL_mouse.c
  SDL_quit.c
  SDL_scancode_tables.c
  SDL_touch.c
  SDL_windowevents.c
  imKStoUCS.c
  SDL_rwops.c
  SDL_haptic.c
  SDL_hidapi.c
  SDL_gamecontroller.c
  SDL_joystick.c
  SDL_steam_virtual_gamepad.c
  controller_type.c
  e_atan2.c
  e_exp.c
  e_fmod.c
  e_log.c
  e_log10.c
  e_pow.c
  e_rem_pio2.c
  e_sqrt.c
  k_cos.c
  k_rem_pio2.c
  k_sin.c
  k_tan.c
  s_atan.c
  s_copysign.c
  s_cos.c
  s_fabs.c
  s_floor.c
  s_scalbn.c
  s_sin.c
  s_tan.c
  SDL_locale.c
  SDL_url.c
  SDL_power.c
  SDL_d3dmath.c
  SDL_render.c
  SDL_yuv_sw.c
  SDL_render_d3d.c
  SDL_shaders_d3d.c
  SDL_render_d3d11.c
  SDL_shaders_d3d11.c
  SDL_render_d3d12.c
  SDL_shaders_d3d12.c
  SDL_render_gl.c
  SDL_shaders_gl.c
  SDL_render_gles.c
  SDL_render_gles2.c
  SDL_shaders_gles2.c
  SDL_render_ps2.c
  SDL_render_psp.c
  SDL_blendfillrect.c
  SDL_blendline.c
  SDL_blendpoint.c
  SDL_drawline.c
  SDL_drawpoint.c
  SDL_render_sw.c
  SDL_rotate.c
  SDL_triangle.c
  SDL_render_vita_gxm.c
  SDL_render_vita_gxm_memory.c
  SDL_render_vita_gxm_tools.c
  SDL_sensor.c
  SDL_crc16.c
  SDL_crc32.c
  SDL_getenv.c
  SDL_iconv.c
  SDL_malloc.c
  SDL_qsort.c
  SDL_stdlib.c
  SDL_string.c
  SDL_strtokr.c
  SDL_thread.c
  SDL_timer.c
  SDL_RLEaccel.c
  SDL_blit.c
  SDL_blit_0.c
  SDL_blit_1.c
  SDL_blit_A.c
  SDL_blit_N.c
  SDL_blit_auto.c
  SDL_blit_copy.c
  SDL_blit_slow.c
  SDL_bmp.c
  SDL_clipboard.c
  SDL_egl.c
  SDL_fillrect.c
  SDL_pixels.c
  SDL_rect.c
  SDL_shape.c
  SDL_stretch.c
  SDL_surface.c
  SDL_video.c
  SDL_vulkan_utils.c
  SDL_yuv.c
  yuv_rgb_lsx.c
  yuv_rgb_sse.c
  yuv_rgb_std.c
  SDL_dummyaudio.c
  SDL_diskaudio.c
  SDL_virtualjoystick.c
  SDL_nullevents.c
  SDL_nullframebuffer.c
  SDL_nullvideo.c
  SDL_offscreenevents.c
  SDL_offscreenframebuffer.c
  SDL_offscreenopengles.c
  SDL_offscreenvideo.c
  SDL_offscreenwindow.c
  SDL_hid.c
  SDL_immdevice.c
  SDL_windows.c
  SDL_xinput.c
  SDL_sysurl.c
  SDL_winmm.c
  SDL_directsound.c
  SDL_wasapi.c
  SDL_wasapi_win32.c
  SDL_windowsclipboard.c
  SDL_windowsevents.c
  SDL_windowsframebuffer.c
  SDL_windowskeyboard.c
  SDL_windowsmessagebox.c
  SDL_windowsmodes.c
  SDL_windowsmouse.c
  SDL_windowsopengl.c
  SDL_windowsopengles.c
  SDL_windowsshape.c
  SDL_windowsvideo.c
  SDL_windowsvulkan.c
  SDL_windowswindow.c
  SDL_syscond.c
  SDL_syscond_cv.c
  SDL_sysmutex.c
  SDL_syssem.c
  SDL_systhread.c
  SDL_systls.c
  SDL_windowssensor.c
  SDL_syspower.c
  SDL_syslocale.c
  SDL_sysfilesystem.c
  SDL_systimer.c
  SDL_sysloadso.c
  SDL_hidapi_combined.c
  SDL_hidapi_gamecube.c
  SDL_hidapi_luna.c
  SDL_hidapi_ps3.c
  SDL_hidapi_ps4.c
  SDL_hidapi_ps5.c
  SDL_hidapi_rumble.c
  SDL_hidapi_shield.c
  SDL_hidapi_stadia.c
  SDL_hidapi_steam.c
  SDL_hidapi_steamdeck.c
  SDL_hidapi_switch.c
  SDL_hidapi_wii.c
  SDL_hidapi_xbox360.c
  SDL_hidapi_xbox360w.c
  SDL_hidapi_xboxone.c
  SDL_hidapijoystick.c
  SDL_dinputjoystick.c
  SDL_rawinputjoystick.c
  SDL_windows_gaming_input.c
  SDL_windowsjoystick.c
  SDL_xinputjoystick.c
  SDL_dinputhaptic.c
  SDL_windowshaptic.c
  SDL_xinputhaptic.c
  SDL_mslibc.c
  SDL2-static.vcxproj -> D:\a\Hellbreak\Hellbreak\build\_deps\sdl2-build\Release\SDL2-static.lib
  Building Custom Rule D:/a/Hellbreak/Hellbreak/CMakeLists.txt
  main.cpp
  Game.cpp
  Renderer.cpp
D:\a\Hellbreak\Hellbreak\src\Game.cpp(304,17): error C2660: 'Renderer::render': function does not take 5 arguments [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(16,10):
      see declaration of 'Renderer::render'
      D:\a\Hellbreak\Hellbreak\src\Game.cpp(304,17):
      while trying to match the argument list '(Map, Player, std::vector<Enemy,std::allocator<Enemy>>, bool, bool)'
  
  Raycaster.cpp
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.h(11,7): error C2011: 'Renderer': 'class' type redefinition [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
  (compiling source file '../src/Engine/Raycaster.cpp')
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(41,11): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(41,11): error C4430: missing type specifier - int assumed. Note: C++ does not support default-int [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(43,21): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(44,1): error C2550: '{ctor}': constructor initializer lists are only allowed on constructor definitions [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(45,1): warning C4508: '{ctor}': function should return a value; 'void' return type assumed [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(47,16): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(56,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(61,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(65,21): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(67,5): error C3861: 'renderWorld': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(68,5): error C3861: 'renderEnemies': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(69,5): error C3861: 'renderWeapon': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(70,5): error C3861: 'renderHUD': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(71,5): error C3861: 'renderMinimap': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(72,5): error C3861: 'renderOverlay': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(74,23): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(77,16): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(83,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(85,9): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(85,16): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(90,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(91,12): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(92,9): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(92,16): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(104,25): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(107,23): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(106,22): error C2737: 'cameraX': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(115,9): error C4430: missing type specifier - int assumed. Note: C++ does not support default-int [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(115,22): error C2146: syntax error: missing ';' before identifier 'hit' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(115,22): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(115,28): error C2653: 'Raycaster': is not a class or namespace name [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(115,39): error C3861: 'cast': identifier not found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(123,14): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(125,13): error C2065: 'm_depthBuffer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(130,22): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(130,18): error C2672: 'std::max': no matching overloaded function found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(85,26):
      could be '_Ty std::max(std::initializer_list<_Elem>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(130,18):
          '_Ty std::max(std::initializer_list<_Elem>)': expects 1 arguments - 2 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(82,26):
      or       '_Ty std::max(std::initializer_list<_Elem>,_Pr)'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(74,6):
      or       'const _Ty &std::max(const _Ty &,const _Ty &) noexcept(<expr>)'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(64,33):
      or       'const _Ty &std::max(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(130,18):
          'const _Ty &std::max(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)': expects 3 arguments - 2 provided
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(129,22): error C2737: 'distance': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(132,9): error C2065: 'm_depthBuffer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(135,30): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(134,19): error C2737: 'wallHeight': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(140,17): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(138,18): error C2672: 'std::max': no matching overloaded function found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(85,26):
      could be '_Ty std::max(std::initializer_list<_Elem>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(138,18):
          '_Ty std::max(std::initializer_list<_Elem>)': could not deduce template argument for 'std::initializer_list<_Elem>' from 'int'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(82,26):
      or       '_Ty std::max(std::initializer_list<_Elem>,_Pr)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(138,18):
          '_Ty std::max(std::initializer_list<_Elem>,_Pr)': expects 2 arguments - 1 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(74,6):
      or       'const _Ty &std::max(const _Ty &,const _Ty &) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(138,18):
          'const _Ty &std::max(const _Ty &,const _Ty &) noexcept(<expr>)': expects 2 arguments - 1 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(64,33):
      or       'const _Ty &std::max(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(138,18):
          'const _Ty &std::max(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)': expects 3 arguments - 1 provided
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(137,19): error C2737: 'start': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(145,17): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(146,17): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(144,18): error C2672: 'std::min': no matching overloaded function found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(109,26):
      could be '_Ty std::min(std::initializer_list<_Elem>)'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(106,26):
      or       '_Ty std::min(std::initializer_list<_Elem>,_Pr)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(144,18):
          '_Ty std::min(std::initializer_list<_Elem>,_Pr)': expects 2 arguments - 1 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(98,6):
      or       'const _Ty &std::min(const _Ty &,const _Ty &) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(144,18):
          'const _Ty &std::min(const _Ty &,const _Ty &) noexcept(<expr>)': expects 2 arguments - 1 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(88,33):
      or       'const _Ty &std::min(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(144,18):
          'const _Ty &std::min(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)': expects 3 arguments - 1 provided
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(143,19): error C2737: 'end': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(153,13): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(159,18): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(167,30): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(166,19): error C2737: 'textureColumn': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(173,13): error C2065: 'hit': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(172,22): error C2737: 'sideShade': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(186,13): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(194,13): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(204,17): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(203,23): error C2737: 'y': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(212,17): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(220,17): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(228,16): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(299,17): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(297,19): error C2737: 'screenX': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(306,21): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(303,19): error C2737: 'spriteHeight': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(317,13): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(316,19): error C2737: 'startY': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(320,13): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(319,19): error C2737: 'endY': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(330,41): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(333,31): error C2065: 'm_depthBuffer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(345,17): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(350,17): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(354,26): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(354,22): error C2672: 'std::min': no matching overloaded function found [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(109,26):
      could be '_Ty std::min(std::initializer_list<_Elem>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(354,22):
          '_Ty std::min(std::initializer_list<_Elem>)': expects 1 arguments - 2 provided
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(106,26):
      or       '_Ty std::min(std::initializer_list<_Elem>,_Pr)'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(98,6):
      or       'const _Ty &std::min(const _Ty &,const _Ty &) noexcept(<expr>)'
      C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Tools\MSVC\14.44.35207\include\utility(88,33):
      or       'const _Ty &std::min(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)'
          D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(354,22):
          'const _Ty &std::min(const _Ty &,const _Ty &,_Pr) noexcept(<expr>)': expects 3 arguments - 2 provided
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(360,21): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(368,21): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(379,16): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(386,24): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(386,15): error C2737: 'center': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(389,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(391,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(398,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(400,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(407,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(409,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(418,13): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(420,13): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(427,13): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(429,13): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(437,16): error C2027: use of undefined type 'Renderer' [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\Engine\Renderer.h(8,7):
      see declaration of 'Renderer'
  
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(440,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(442,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(443,9): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(449,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(451,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(461,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(463,9): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(477,13): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(478,13): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(479,13): error C2065: 'HEIGHT': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(489,9): error C2065: 'm_renderer': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(493,20): error C2065: 'WIDTH': undeclared identifier [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(493,15): error C2737: 'cx': const object must be initialized [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\Engine\Raycaster.cpp(493,15): error C1003: error count exceeds 100; stopping compilation [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
  Map.cpp
D:\a\Hellbreak\Hellbreak\src\World\Map.cpp(16,9): error C2078: too many initializers [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
D:\a\Hellbreak\Hellbreak\src\World\Map.cpp(9,5): error C2131: expression did not evaluate to a constant [D:\a\Hellbreak\Hellbreak\build\Hellbreak.vcxproj]
      D:\a\Hellbreak\Hellbreak\src\World\Map.cpp(9,5):
      a non-constant (sub-)expression was encountered
  
  Player.cpp
  Enemy.cpp
  Generating Code...
Exception: D:\a\_temp\314a5cc2-f9ee-4789-aa4b-1dc96c64f03f.ps1:7
Line |
   7 |    throw "Hellbreak compilation failed!"
     |    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     | Hellbreak compilation failed!
Error: Process completed with exit code 1.
#include "Raycaster.h"

#include <algorithm>
#include <cmath>
#include <limits>

RayHit Raycaster::cast(
    const Map& map,
    double originX,
    double originY,
    double directionX,
    double directionY
)
{
    RayHit result{};

    constexpr double EPSILON = 0.000001;
    constexpr double MAX_DISTANCE = 64.0;

    // Начальная клетка карты
    int mapX = static_cast<int>(std::floor(originX));
    int mapY = static_cast<int>(std::floor(originY));

    // Расстояние между пересечениями сетки
    const double deltaDistX =
        std::abs(directionX) < EPSILON
            ? std::numeric_limits<double>::infinity()
            : std::abs(1.0 / directionX);

    const double deltaDistY =
        std::abs(directionY) < EPSILON
            ? std::numeric_limits<double>::infinity()
            : std::abs(1.0 / directionY);

    // Направление движения луча
    int stepX = 0;
    int stepY = 0;

    // Расстояние до ближайшей границы клетки
    double sideDistX = 0.0;
    double sideDistY = 0.0;

    if (directionX < 0.0)
    {
        stepX = -1;

        sideDistX =
            (originX - static_cast<double>(mapX)) *
            deltaDistX;
    }
    else
    {
        stepX = 1;

        sideDistX =
            (static_cast<double>(mapX) + 1.0 - originX) *
            deltaDistX;
    }

    if (directionY < 0.0)
    {
        stepY = -1;

        sideDistY =
            (originY - static_cast<double>(mapY)) *
            deltaDistY;
    }
    else
    {
        stepY = 1;

        sideDistY =
            (static_cast<double>(mapY) + 1.0 - originY) *
            deltaDistY;
    }

    int side = 0;

    // DDA: последовательный обход клеток карты
    constexpr int MAX_STEPS = 256;

    for (int i = 0; i < MAX_STEPS; ++i)
    {
        double distance = 0.0;

        if (sideDistX < sideDistY)
        {
            distance = sideDistX;

            sideDistX += deltaDistX;
            mapX += stepX;

            side = 0;
        }
        else
        {
            distance = sideDistY;

            sideDistY += deltaDistY;
            mapY += stepY;

            side = 1;
        }

        if (distance > MAX_DISTANCE)
        {
            break;
        }

        // Проверяем наличие стены
        const int wallType = map.at(mapX, mapY);

        if (wallType == 0)
        {
            continue;
        }

        // Луч попал в стену
        result.hit = true;

        result.mapX = mapX;
        result.mapY = mapY;

        result.wallType = wallType;
        result.side = side;

        result.distance = std::max(distance, EPSILON);

        // Точка попадания в стену
        double wallX = 0.0;

        if (side == 0)
        {
            wallX =
                originY +
                result.distance * directionY;
        }
        else
        {
            wallX =
                originX +
                result.distance * directionX;
        }

        // Дробная часть координаты
        wallX -= std::floor(wallX);

        // Корректируем направление текстуры
        if (side == 0 && directionX > 0.0)
        {
            wallX = 1.0 - wallX;
        }

        if (side == 1 && directionY < 0.0)
        {
            wallX = 1.0 - wallX;
        }

        result.textureX = std::clamp(
            wallX,
            0.0,
            1.0
        );

        return result;
    }

    // Стена не найдена
    result.hit = false;
    result.distance = MAX_DISTANCE;
    result.textureX = 0.0;
    result.wallType = 0;
    result.side = 0;
    result.mapX = mapX;
    result.mapY = mapY;

    return result;
}
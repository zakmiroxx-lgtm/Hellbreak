#include "Renderer.h"
#include "Raycaster.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>

namespace
{
    constexpr double PI = 3.14159265358979323846;
    constexpr double FOV = PI / 3.0;

    void setColor(
        SDL_Renderer* renderer,
        int r,
        int g,
        int b,
        int a = 255
    )
    {
        SDL_SetRenderDrawColor(
            renderer,
            static_cast<Uint8>(std::clamp(r, 0, 255)),
            static_cast<Uint8>(std::clamp(g, 0, 255)),
            static_cast<Uint8>(std::clamp(b, 0, 255)),
            static_cast<Uint8>(std::clamp(a, 0, 255))
        );
    }

    void fillRect(
        SDL_Renderer* renderer,
        int x,
        int y,
        int w,
        int h
    )
    {
        if (w <= 0 || h <= 0)
            return;

        SDL_Rect rect{x, y, w, h};
        SDL_RenderFillRect(renderer, &rect);
    }

    void drawRect(
        SDL_Renderer* renderer,
        int x,
        int y,
        int w,
        int h
    )
    {
        if (w <= 0 || h <= 0)
            return;

        SDL_Rect rect{x, y, w, h};
        SDL_RenderDrawRect(renderer, &rect);
    }
}

Renderer::Renderer(SDL_Renderer* renderer)
    : m_renderer(renderer),
      m_depthBuffer(
          WIDTH,
          std::numeric_limits<double>::infinity()
      )
{
}

void Renderer::render(
    const Map& map,
    const Player& player,
    const std::vector<Enemy>& enemies,
    bool gameOver,
    bool victory
)
{
    if (!m_renderer)
        return;

    setColor(m_renderer, 0, 0, 0);
    SDL_RenderClear(m_renderer);

    renderWorld(map, player);
    renderEnemies(player, enemies);
    renderWeapon(player);
    renderHUD(player);
    renderMinimap(map, player, enemies);

    if (gameOver || victory)
    {
        renderOverlay(gameOver, victory);
    }

    SDL_RenderPresent(m_renderer);
}

void Renderer::renderWorld(
    const Map& map,
    const Player& player
)
{
    // Небо
    setColor(m_renderer, 28, 20, 34);
    fillRect(m_renderer, 0, 0, WIDTH, HEIGHT / 2);

    // Пол
    setColor(m_renderer, 35, 31, 30);
    fillRect(
        m_renderer,
        0,
        HEIGHT / 2,
        WIDTH,
        HEIGHT / 2
    );

    const double dirX = std::cos(player.angle);
    const double dirY = std::sin(player.angle);

    const double planeScale = std::tan(FOV / 2.0);

    const double planeX = -dirY * planeScale;
    const double planeY = dirX * planeScale;

    for (int x = 0; x < WIDTH; ++x)
    {
        const double cameraX =
            2.0 * static_cast<double>(x) /
            static_cast<double>(WIDTH) - 1.0;

        const double rayDirX =
            dirX + planeX * cameraX;

        const double rayDirY =
            dirY + planeY * cameraX;

        const RayHit hit = Raycaster::cast(
            map,
            player.x,
            player.y,
            rayDirX,
            rayDirY
        );

        if (!hit.hit)
        {
            m_depthBuffer[x] =
                std::numeric_limits<double>::infinity();

            continue;
        }

        const double distance =
            std::max(hit.distance, 0.0001);

        m_depthBuffer[x] = distance;

        const int wallHeight =
            static_cast<int>(
                static_cast<double>(HEIGHT) /
                distance
            );

        const int start =
            std::max(
                0,
                HEIGHT / 2 - wallHeight / 2
            );

        const int end =
            std::min(
                HEIGHT - 1,
                HEIGHT / 2 + wallHeight / 2
            );

        int baseR = 130;
        int baseG = 48;
        int baseB = 38;

        if (hit.wallType == 2)
        {
            baseR = 105;
            baseG = 105;
            baseB = 115;
        }
        else if (hit.wallType == 3)
        {
            baseR = 90;
            baseG = 100;
            baseB = 65;
        }

        // Процедурный рисунок поверхности
        const int textureColumn =
            static_cast<int>(hit.textureX * 64.0);

        const bool stripe =
            (textureColumn % 16) < 2;

        const double sideShade =
            hit.side == 1 ? 0.72 : 1.0;

        const double distanceShade =
            std::clamp(
                1.0 - distance / 24.0,
                0.20,
                1.0
            );

        const double shade =
            sideShade * distanceShade *
            (stripe ? 0.65 : 1.0);

        setColor(
            m_renderer,
            static_cast<int>(baseR * shade),
            static_cast<int>(baseG * shade),
            static_cast<int>(baseB * shade)
        );

        SDL_RenderDrawLine(
            m_renderer,
            x,
            start,
            x,
            end
        );

        // Горизонтальные швы
        if (wallHeight > 20)
        {
            const int visibleHeight =
                end - start;

            const int seam1 =
                start + visibleHeight / 3;

            const int seam2 =
                start + visibleHeight * 2 / 3;

            setColor(
                m_renderer,
                static_cast<int>(baseR * shade * 0.55),
                static_cast<int>(baseG * shade * 0.55),
                static_cast<int>(baseB * shade * 0.55)
            );

            SDL_RenderDrawPoint(
                m_renderer,
                x,
                seam1
            );

            SDL_RenderDrawPoint(
                m_renderer,
                x,
                seam2
            );
        }
    }
}

void Renderer::renderEnemies(
    const Player& player,
    const std::vector<Enemy>& enemies
)
{
    const double dirX = std::cos(player.angle);
    const double dirY = std::sin(player.angle);

    const double planeScale =
        std::tan(FOV / 2.0);

    const double planeX = -dirY * planeScale;
    const double planeY = dirX * planeScale;

    const double determinant =
        planeX * dirY - dirX * planeY;

    if (std::abs(determinant) < 0.000001)
        return;

    const double inverseDet =
        1.0 / determinant;

    for (const Enemy& enemy : enemies)
    {
        if (!enemy.alive || enemy.health <= 0)
            continue;

        const double spriteX =
            enemy.x - player.x;

        const double spriteY =
            enemy.y - player.y;

        const double transformX =
            inverseDet *
            (dirY * spriteX - dirX * spriteY);

        const double transformY =
            inverseDet *
            (-planeY * spriteX + planeX * spriteY);

        if (transformY <= 0.05)
            continue;

        const int screenX =
            static_cast<int>(
                (WIDTH / 2.0) *
                (1.0 + transformX / transformY)
            );

        const int spriteHeight =
            std::abs(
                static_cast<int>(
                    HEIGHT / transformY
                )
            );

        const int spriteWidth =
            std::max(
                1,
                spriteHeight / 2
            );

        const int startY =
            HEIGHT / 2 - spriteHeight / 2;

        const int endY =
            HEIGHT / 2 + spriteHeight / 2;

        const int startX =
            screenX - spriteWidth / 2;

        const int endX =
            screenX + spriteWidth / 2;

        const double shade =
            std::clamp(
                1.0 - transformY / 20.0,
                0.25,
                1.0
            );

        for (int stripe = startX;
             stripe <= endX;
             ++stripe)
        {
            if (stripe < 0 || stripe >= WIDTH)
                continue;

            if (transformY >= m_depthBuffer[stripe])
                continue;

            const double relativeX =
                static_cast<double>(stripe - startX) /
                std::max(1, spriteWidth);

            // Голова
            setColor(
                m_renderer,
                static_cast<int>(175 * shade),
                static_cast<int>(45 * shade),
                static_cast<int>(45 * shade)
            );

            SDL_RenderDrawLine(
                m_renderer,
                stripe,
                std::max(0, startY),
                stripe,
                std::min(
                    HEIGHT - 1,
                    startY + spriteHeight / 3
                )
            );

            // Тело
            setColor(
                m_renderer,
                static_cast<int>(95 * shade),
                static_cast<int>(25 * shade),
                static_cast<int>(30 * shade)
            );

            SDL_RenderDrawLine(
                m_renderer,
                stripe,
                std::max(
                    0,
                    startY + spriteHeight / 3
                ),
                stripe,
                std::min(
                    HEIGHT - 1,
                    endY
                )
            );

            // Светящиеся глаза
            if (
                (relativeX > 0.25 && relativeX < 0.38) ||
                (relativeX > 0.62 && relativeX < 0.75)
            )
            {
                setColor(
                    m_renderer,
                    255,
                    190,
                    35
                );

                const int eyeY =
                    startY + spriteHeight / 5;

                SDL_RenderDrawPoint(
                    m_renderer,
                    stripe,
                    eyeY
                );

                SDL_RenderDrawPoint(
                    m_renderer,
                    stripe,
                    eyeY + 1
                );
            }
        }
    }
}

void Renderer::renderWeapon(
    const Player& player
)
{
    const int center = WIDTH / 2;

    const int animationOffset =
        static_cast<int>(
            player.weaponAnimation * 35.0
        );

    // Рукоять
    setColor(m_renderer, 45, 45, 52);

    fillRect(
        m_renderer,
        center - 35,
        HEIGHT - 115 + animationOffset,
        70,
        115
    );

    // Корпус
    setColor(m_renderer, 85, 85, 95);

    fillRect(
        m_renderer,
        center - 65,
        HEIGHT - 155 + animationOffset,
        130,
        105
    );

    // Центральная часть
    setColor(m_renderer, 125, 125, 135);

    fillRect(
        m_renderer,
        center - 25,
        HEIGHT - 200 + animationOffset,
        50,
        110
    );

    // Ствол
    setColor(m_renderer, 35, 35, 40);

    fillRect(
        m_renderer,
        center - 16,
        HEIGHT - 215 + animationOffset,
        32,
        55
    );

    // Вспышка выстрела
    if (player.weaponAnimation > 0.01)
    {
        setColor(m_renderer, 255, 190, 35);

        fillRect(
            m_renderer,
            center - 25,
            HEIGHT - 250 + animationOffset,
            50,
            45
        );

        setColor(m_renderer, 255, 245, 150);

        fillRect(
            m_renderer,
            center - 12,
            HEIGHT - 265 + animationOffset,
            24,
            55
        );
    }
}

void Renderer::renderHUD(
    const Player& player
)
{
    // Нижняя панель
    setColor(m_renderer, 18, 18, 23);

    fillRect(
        m_renderer,
        0,
        HEIGHT - 65,
        WIDTH,
        65
    );

    // Рамка здоровья
    setColor(m_renderer, 90, 90, 95);

    drawRect(
        m_renderer,
        25,
        HEIGHT - 45,
        205,
        25
    );

    // Здоровье
    const int health =
        std::clamp(player.health, 0, 100);

    setColor(
        m_renderer,
        health > 30 ? 180 : 240,
        health > 30 ? 45 : 20,
        35
    );

    fillRect(
        m_renderer,
        28,
        HEIGHT - 42,
        health * 199 / 100,
        19
    );

    // Индикатор патронов
    const int visibleAmmo =
        std::clamp(player.ammo, 0, 60);

    for (int i = 0; i < visibleAmmo; ++i)
    {
        const int x =
            WIDTH - 215 + (i % 20) * 9;

        const int y =
            HEIGHT - 48 + (i / 20) * 13;

        setColor(
            m_renderer,
            230,
            175,
            55
        );

        fillRect(
            m_renderer,
            x,
            y,
            5,
            9
        );
    }

    // Прицел
    const int cx = WIDTH / 2;
    const int cy = HEIGHT / 2;

    setColor(m_renderer, 230, 230, 220);

    SDL_RenderDrawLine(
        m_renderer,
        cx - 12,
        cy,
        cx - 4,
        cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx + 4,
        cy,
        cx + 12,
        cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx,
        cy - 12,
        cx,
        cy - 4
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx,
        cy + 4,
        cx,
        cy + 12
    );
}

void Renderer::renderMinimap(
    const Map& map,
    const Player& player,
    const std::vector<Enemy>& enemies
)
{
    constexpr int CELL = 7;

    constexpr int OFFSET_X = 15;
    constexpr int OFFSET_Y = 15;

    const int mapWidth =
        Map::WIDTH * CELL;

    const int mapHeight =
        Map::HEIGHT * CELL;

    // Фон мини-карты
    setColor(m_renderer, 12, 12, 16);

    fillRect(
        m_renderer,
        OFFSET_X - 5,
        OFFSET_Y - 5,
        mapWidth + 10,
        mapHeight + 10
    );

    // Стены
    for (int y = 0; y < Map::HEIGHT; ++y)
    {
        for (int x = 0; x < Map::WIDTH; ++x)
        {
            const int tile = map.tile(x, y);

            if (tile == 0)
            {
                setColor(
                    m_renderer,
                    35,
                    35,
                    42
                );
            }
            else
            {
                setColor(
                    m_renderer,
                    115,
                    55,
                    50
                );
            }

            fillRect(
                m_renderer,
                OFFSET_X + x * CELL,
                OFFSET_Y + y * CELL,
                CELL - 1,
                CELL - 1
            );
        }
    }

    // Противники
    for (const Enemy& enemy : enemies)
    {
        if (!enemy.alive || enemy.health <= 0)
            continue;

        setColor(m_renderer, 240, 60, 45);

        fillRect(
            m_renderer,
            OFFSET_X +
                static_cast<int>(enemy.x * CELL) - 2,
            OFFSET_Y +
                static_cast<int>(enemy.y * CELL) - 2,
            5,
            5
        );
    }

    // Игрок
    const int px =
        OFFSET_X +
        static_cast<int>(player.x * CELL);

    const int py =
        OFFSET_Y +
        static_cast<int>(player.y * CELL);

    setColor(m_renderer, 60, 235, 100);

    fillRect(
        m_renderer,
        px - 3,
        py - 3,
        7,
        7
    );

    // Направление взгляда
    SDL_RenderDrawLine(
        m_renderer,
        px,
        py,
        px + static_cast<int>(
            std::cos(player.angle) * 14.0
        ),
        py + static_cast<int>(
            std::sin(player.angle) * 14.0
        )
    );
}

void Renderer::renderOverlay(
    bool gameOver,
    bool victory
)
{
    SDL_SetRenderDrawBlendMode(
        m_renderer,
        SDL_BLENDMODE_BLEND
    );

    // Затемнение экрана
    setColor(
        m_renderer,
        0,
        0,
        0,
        170
    );

    fillRect(
        m_renderer,
        0,
        0,
        WIDTH,
        HEIGHT
    );

    if (victory)
    {
        // Зелёная панель победы
        setColor(
            m_renderer,
            35,
            150,
            65,
            230
        );
    }
    else if (gameOver)
    {
        // Красная панель поражения
        setColor(
            m_renderer,
            170,
            35,
            35,
            230
        );
    }

    fillRect(
        m_renderer,
        WIDTH / 2 - 220,
        HEIGHT / 2 - 75,
        440,
        150
    );

    setColor(m_renderer, 230, 230, 230);

    drawRect(
        m_renderer,
        WIDTH / 2 - 220,
        HEIGHT / 2 - 75,
        440,
        150
    );

    SDL_SetRenderDrawBlendMode(
        m_renderer,
        SDL_BLENDMODE_NONE
    );
}
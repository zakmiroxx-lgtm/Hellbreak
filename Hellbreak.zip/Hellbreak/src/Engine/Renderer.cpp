#include "Raycaster.h"

#include <cmath>
#include <algorithm>

RayHit Raycaster::cast(
    const Map& map,
    double originX,
    double originY,
    double directionX,
    double directionY
)
{
    RayHit result;

    int mapX = static_cast<int>(
        std::floor(originX)
    );

    int mapY = static_cast<int>(
        std::floor(originY)
    );

    const double deltaDistX =
        directionX == 0.0
        ? 1e30
        : std::abs(1.0 / directionX);

    const double deltaDistY =
        directionY == 0.0
        ? 1e30
        : std::abs(1.0 / directionY);

    double sideDistX;
    double sideDistY;

    int stepX;
    int stepY;

    if (directionX < 0.0)
    {
        stepX = -1;

        sideDistX =
            (originX - mapX) * deltaDistX;
    }
    else
    {
        stepX = 1;

        sideDistX =
            (mapX + 1.0 - originX) * deltaDistX;
    }

    if (directionY < 0.0)
    {
        stepY = -1;

        sideDistY =
            (originY - mapY) * deltaDistY;
    }
    else
    {
        stepY = 1;

        sideDistY =
            (mapY + 1.0 - originY) * deltaDistY;
    }

    int side = 0;
    int wallType = 0;

    for (int i = 0; i < 128; ++i)
    {
        if (sideDistX < sideDistY)
        {
            sideDistX += deltaDistX;

            mapX += stepX;

            side = 0;
        }
        else
        {
            sideDistY += deltaDistY;

            mapY += stepY;

            side = 1;
        }

        wallType = map.tile(mapX, mapY);

        if (wallType != 0)
        {
            result.hit = true;
            break;
        }
    }

    if (!result.hit)
    {
        return result;
    }

    double distance;

    if (side == 0)
    {
        distance =
            sideDistX - deltaDistX;
    }
    else
    {
        distance =
            sideDistY - deltaDistY;
    }

    distance = std::max(
        distance,
        0.0001
    );

    double textureX;

    if (side == 0)
    {
        textureX =
            originY + distance * directionY;
    }
    else
    {
        textureX =
            originX + distance * directionX;
    }

    textureX -= std::floor(textureX);

    result.distance = distance;
    result.textureX = textureX;

    result.wallType = wallType;
    result.side = side;

    result.mapX = mapX;
    result.mapY = mapY;

    return result;
}
#include "Renderer.h"

#include <cmath>
#include <algorithm>
#include <cstdint>

namespace
{
    constexpr double FOV = 1.0471975512;

    Uint8 clampColor(double value)
    {
        return static_cast<Uint8>(
            std::clamp(value, 0.0, 255.0)
        );
    }
}

Renderer::Renderer(SDL_Renderer* renderer)
    : m_renderer(renderer)
{
}

void Renderer::render(
    const Map& map,
    const Player& player
)
{
    SDL_SetRenderDrawColor(
        m_renderer,
        0, 0, 0, 255
    );

    SDL_RenderClear(m_renderer);

    renderWorld(map, player);
    renderMinimap(map, player);
    renderCrosshair();

    SDL_RenderPresent(m_renderer);
}

void Renderer::renderWorld(
    const Map& map,
    const Player& player
)
{
    // Ceiling

    SDL_SetRenderDrawColor(
        m_renderer,
        27, 31, 43, 255
    );

    SDL_Rect ceiling = {
        0, 0, WIDTH, HEIGHT / 2
    };

    SDL_RenderFillRect(
        m_renderer,
        &ceiling
    );

    // Floor

    SDL_SetRenderDrawColor(
        m_renderer,
        49, 43, 43, 255
    );

    SDL_Rect floor = {
        0, HEIGHT / 2,
        WIDTH, HEIGHT / 2
    };

    SDL_RenderFillRect(
        m_renderer,
        &floor
    );

    // Raycasting

    const double dirX = std::cos(player.angle);
    const double dirY = std::sin(player.angle);

    const double planeLength = std::tan(FOV / 2.0);

    const double planeX = -dirY * planeLength;
    const double planeY = dirX * planeLength;

    for (int screenX = 0; screenX < WIDTH; ++screenX)
    {
        const double cameraX =
            2.0 * screenX / WIDTH - 1.0;

        const double rayDirX =
            dirX + planeX * cameraX;

        const double rayDirY =
            dirY + planeY * cameraX;

        int mapX = static_cast<int>(
            std::floor(player.x)
        );

        int mapY = static_cast<int>(
            std::floor(player.y)
        );

        const double deltaDistX =
            rayDirX == 0.0
            ? 1e30
            : std::abs(1.0 / rayDirX);

        const double deltaDistY =
            rayDirY == 0.0
            ? 1e30
            : std::abs(1.0 / rayDirY);

        double sideDistX;
        double sideDistY;

        int stepX;
        int stepY;

        if (rayDirX < 0)
        {
            stepX = -1;

            sideDistX =
                (player.x - mapX) * deltaDistX;
        }
        else
        {
            stepX = 1;

            sideDistX =
                (mapX + 1.0 - player.x) * deltaDistX;
        }

        if (rayDirY < 0)
        {
            stepY = -1;

            sideDistY =
                (player.y - mapY) * deltaDistY;
        }
        else
        {
            stepY = 1;

            sideDistY =
                (mapY + 1.0 - player.y) * deltaDistY;
        }

        int side = 0;
        int wallType = 0;

        for (int i = 0; i < 64; ++i)
        {
            if (sideDistX < sideDistY)
            {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0;
            }
            else
            {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1;
            }

            wallType = map.tile(mapX, mapY);

            if (wallType != 0)
            {
                break;
            }
        }

        double distance;

        if (side == 0)
        {
            distance =
                sideDistX - deltaDistX;
        }
        else
        {
            distance =
                sideDistY - deltaDistY;
        }

        distance = std::max(distance, 0.05);

        const int lineHeight =
            static_cast<int>(HEIGHT / distance);

        const int drawStart =
            std::max(
                0,
                HEIGHT / 2 - lineHeight / 2
            );

        const int drawEnd =
            std::min(
                HEIGHT - 1,
                HEIGHT / 2 + lineHeight / 2
            );

        // Determine wall texture coordinate

        double wallX;

        if (side == 0)
        {
            wallX =
                player.y + distance * rayDirY;
        }
        else
        {
            wallX =
                player.x + distance * rayDirX;
        }

        wallX -= std::floor(wallX);

        // Procedural texture

        const int brickX =
            static_cast<int>(wallX * 8.0);

        double textureShade =
            (brickX % 2 == 0) ? 1.0 : 0.82;

        double red = 150;
        double green = 75;
        double blue = 65;

        if (wallType == 2)
        {
            red = 85;
            green = 110;
            blue = 155;
        }
        else if (wallType == 3)
        {
            red = 95;
            green = 135;
            blue = 110;
        }

        const double fog =
            1.0 / (1.0 + distance * 0.09);

        const double sideShade =
            side == 1 ? 0.72 : 1.0;

        const double shade =
            textureShade * fog * sideShade;

        red *= shade;
        green *= shade;
        blue *= shade;

        SDL_SetRenderDrawColor(
            m_renderer,
            clampColor(red),
            clampColor(green),
            clampColor(blue),
            255
        );

        SDL_RenderDrawLine(
            m_renderer,
            screenX,
            drawStart,
            screenX,
            drawEnd
        );

        // Horizontal wall texture lines

        const int textureRows = 8;

        for (int row = 1; row < textureRows; ++row)
        {
            const int lineY =
                HEIGHT / 2 -
                lineHeight / 2 +
                lineHeight * row / textureRows;

            if (lineY < drawStart || lineY > drawEnd)
            {
                continue;
            }

            SDL_SetRenderDrawColor(
                m_renderer,
                clampColor(red * 0.55),
                clampColor(green * 0.55),
                clampColor(blue * 0.55),
                255
            );

            SDL_RenderDrawPoint(
                m_renderer,
                screenX,
                lineY
            );
        }
    }
}

void Renderer::renderMinimap(
    const Map& map,
    const Player& player
)
{
    constexpr int SCALE = 8;

    constexpr int OFFSET_X = 16;
    constexpr int OFFSET_Y = 16;

    SDL_SetRenderDrawBlendMode(
        m_renderer,
        SDL_BLENDMODE_BLEND
    );

    SDL_SetRenderDrawColor(
        m_renderer,
        10, 12, 18, 220
    );

    SDL_Rect background = {
        OFFSET_X - 6,
        OFFSET_Y - 6,
        Map::WIDTH * SCALE + 12,
        Map::HEIGHT * SCALE + 12
    };

    SDL_RenderFillRect(
        m_renderer,
        &background
    );

    for (int y = 0; y < Map::HEIGHT; ++y)
    {
        for (int x = 0; x < Map::WIDTH; ++x)
        {
            SDL_Rect tile = {
                OFFSET_X + x * SCALE,
                OFFSET_Y + y * SCALE,
                SCALE - 1,
                SCALE - 1
            };

            if (map.tile(x, y) != 0)
            {
                SDL_SetRenderDrawColor(
                    m_renderer,
                    130, 65, 70, 255
                );
            }
            else
            {
                SDL_SetRenderDrawColor(
                    m_renderer,
                    36, 40, 49, 255
                );
            }

            SDL_RenderFillRect(
                m_renderer,
                &tile
            );
        }
    }

    const int px =
        OFFSET_X +
        static_cast<int>(player.x * SCALE);

    const int py =
        OFFSET_Y +
        static_cast<int>(player.y * SCALE);

    SDL_SetRenderDrawColor(
        m_renderer,
        80, 235, 145, 255
    );

    SDL_Rect marker = {
        px - 3,
        py - 3,
        6,
        6
    };

    SDL_RenderFillRect(
        m_renderer,
        &marker
    );

    const int lookX =
        px + static_cast<int>(
            std::cos(player.angle) * 14
        );

    const int lookY =
        py + static_cast<int>(
            std::sin(player.angle) * 14
        );

    SDL_RenderDrawLine(
        m_renderer,
        px,
        py,
        lookX,
        lookY
    );
}

void Renderer::renderCrosshair()
{
    const int cx = WIDTH / 2;
    const int cy = HEIGHT / 2;

    SDL_SetRenderDrawColor(
        m_renderer,
        220, 230, 225, 255
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx - 9,
        cy,
        cx - 3,
        cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx + 3,
        cy,
        cx + 9,
        cy
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx,
        cy - 9,
        cx,
        cy - 3
    );

    SDL_RenderDrawLine(
        m_renderer,
        cx,
        cy + 3,
        cx,
        cy + 9
    );
}
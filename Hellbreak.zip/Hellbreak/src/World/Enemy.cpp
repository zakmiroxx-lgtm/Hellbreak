#include "Enemy.h"

#include <cmath>
#include <algorithm>

Enemy::Enemy(double x, double y)
    : m_x(x),
      m_y(y)
{
}

void Enemy::update(
    const Map& map,
    Player& player,
    double deltaTime
)
{
    if (!isAlive())
    {
        m_state = State::Dead;
        return;
    }

    if (!player.isAlive())
    {
        m_state = State::Idle;
        return;
    }

    m_attackCooldown = std::max(
        0.0,
        m_attackCooldown - deltaTime
    );

    const double dx = player.x - m_x;
    const double dy = player.y - m_y;

    const double distance =
        std::hypot(dx, dy);

    constexpr double detectionRange = 10.0;
    constexpr double attackRange = 1.1;

    if (distance > detectionRange)
    {
        m_state = State::Idle;
        return;
    }

    if (!map.hasLineOfSight(
        m_x,
        m_y,
        player.x,
        player.y
    ))
    {
        m_state = State::Idle;
        return;
    }

    if (distance <= attackRange)
    {
        m_state = State::Attack;

        if (m_attackCooldown <= 0.0)
        {
            player.takeDamage(10);

            m_attackCooldown = 1.0;
        }

        return;
    }

    m_state = State::Chase;

    if (distance < 0.001)
        return;

    const double directionX = dx / distance;
    const double directionY = dy / distance;

    const double step =
        m_speed * deltaTime;

    const double nextX =
        m_x + directionX * step;

    const double nextY =
        m_y + directionY * step;

    if (map.isWalkable(nextX, m_y, 0.2))
        m_x = nextX;

    if (map.isWalkable(m_x, nextY, 0.2))
        m_y = nextY;
}

void Enemy::takeDamage(int damage)
{
    if (!isAlive())
        return;

    m_health = std::max(
        0,
        m_health - std::max(0, damage)
    );

    if (m_health == 0)
        m_state = State::Dead;
}

bool Enemy::isAlive() const
{
    return m_health > 0;
}

double Enemy::x() const
{
    return m_x;
}

double Enemy::y() const
{
    return m_y;
}

int Enemy::health() const
{
    return m_health;
}

Enemy::State Enemy::state() const
{
    return m_state;
}
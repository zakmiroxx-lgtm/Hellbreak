#pragma once

#include "Map.h"

class Player
{
public:
    double x = 5.5;
    double y = 5.5;

    double angle = 0.0;

    double moveSpeed = 3.5;
    double mouseSensitivity = 0.0025;

    int health = 100;
    int maxHealth = 100;

    int ammo = 60;
    int kills = 0;

    double weaponCooldown = 0.0;
    double weaponAnimation = 0.0;

    void move(
        const Map& map,
        double forward,
        double strafe,
        double deltaTime
    );

    void rotate(double amount);

    void update(double deltaTime);

    bool canShoot() const;

    void shoot();

    void takeDamage(int amount);

    void heal(int amount);

    bool isAlive() const;
};
#include "Player.h"

#include <cmath>
#include <algorithm>

void Player::move(
    const Map& map,
    double forward,
    double strafe,
    double deltaTime
)
{
    const double length =
        std::hypot(forward, strafe);

    if (length > 1.0)
    {
        forward /= length;
        strafe /= length;
    }

    const double dirX = std::cos(angle);
    const double dirY = std::sin(angle);

    const double rightX = -dirY;
    const double rightY = dirX;

    const double dx =
        (dirX * forward + rightX * strafe) *
        moveSpeed * deltaTime;

    const double dy =
        (dirY * forward + rightY * strafe) *
        moveSpeed * deltaTime;

    if (map.isWalkable(x + dx, y))
        x += dx;

    if (map.isWalkable(x, y + dy))
        y += dy;
}

void Player::rotate(double amount)
{
    angle += amount;

    constexpr double TWO_PI =
        6.283185307179586;

    angle = std::fmod(angle, TWO_PI);

    if (angle < 0.0)
        angle += TWO_PI;
}

void Player::update(double deltaTime)
{
    weaponCooldown = std::max(
        0.0,
        weaponCooldown - deltaTime
    );

    weaponAnimation = std::max(
        0.0,
        weaponAnimation - deltaTime
    );
}

bool Player::canShoot() const
{
    return
        isAlive() &&
        ammo > 0 &&
        weaponCooldown <= 0.0;
}

void Player::shoot()
{
    if (!canShoot())
        return;

    ammo--;

    weaponCooldown = 0.25;
    weaponAnimation = 0.15;
}

void Player::takeDamage(int amount)
{
    health = std::clamp(
        health - std::max(0, amount),
        0,
        maxHealth
    );
}

void Player::heal(int amount)
{
    health = std::clamp(
        health + std::max(0, amount),
        0,
        maxHealth
    );
}

bool Player::isAlive() const
{
    return health > 0;
}
#pragma once

#include <array>
#include <vector>

class Map
{
public:
    static constexpr int WIDTH = 24;
    static constexpr int HEIGHT = 24;

    Map();

    int tile(int x, int y) const;

    bool isWall(double x, double y) const;

    bool isWalkable(double x, double y, double radius = 0.2) const;

    bool hasLineOfSight(
        double x1,
        double y1,
        double x2,
        double y2
    ) const;

private:
    std::array<int, WIDTH * HEIGHT> m_tiles{};
};
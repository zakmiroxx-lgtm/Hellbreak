#pragma once

#include "Map.h"
#include "Player.h"

class Enemy
{
public:
    enum class State
    {
        Idle,
        Chase,
        Attack,
        Dead
    };

    Enemy(double x, double y);

    void update(
        const Map& map,
        Player& player,
        double deltaTime
    );

    void takeDamage(int damage);

    bool isAlive() const;

    double x() const;
    double y() const;

    int health() const;

    State state() const;

private:
    double m_x;
    double m_y;

    int m_health = 100;

    double m_speed = 1.2;

    double m_attackCooldown = 0.0;

    State m_state = State::Idle;
};
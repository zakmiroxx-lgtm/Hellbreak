#include "Map.h"

#include <cmath>
#include <algorithm>

Map::Map()
{
    m_tiles.fill(0);

    // Outer walls

    for (int x = 0; x < WIDTH; ++x)
    {
        m_tiles[x] = 1;

        m_tiles[(HEIGHT - 1) * WIDTH + x] = 1;
    }

    for (int y = 0; y < HEIGHT; ++y)
    {
        m_tiles[y * WIDTH] = 1;

        m_tiles[y * WIDTH + WIDTH - 1] = 1;
    }

    // Decorative walls

    for (int x = 2; x <= 3; ++x)
    {
        m_tiles[2 * WIDTH + x] = 2;
    }

    for (int y = 2; y <= 4; ++y)
    {
        m_tiles[y * WIDTH + 12] = 3;
    }

    // Additional obstacles

    for (int x = 8; x <= 11; ++x)
    {
        m_tiles[9 * WIDTH + x] = 2;
    }

    for (int y = 13; y <= 17; ++y)
    {
        m_tiles[y * WIDTH + 15] = 3;
    }
}

int Map::tile(int x, int y) const
{
    if (
        x < 0 ||
        y < 0 ||
        x >= WIDTH ||
        y >= HEIGHT
    )
    {
        return 1;
    }

    return m_tiles[y * WIDTH + x];
}

bool Map::isWall(double x, double y) const
{
    const int tx =
        static_cast<int>(std::floor(x));

    const int ty =
        static_cast<int>(std::floor(y));

    return tile(tx, ty) != 0;
}

bool Map::isWalkable(
    double x,
    double y,
    double radius
) const
{
    return
        !isWall(x - radius, y - radius) &&
        !isWall(x + radius, y - radius) &&
        !isWall(x - radius, y + radius) &&
        !isWall(x + radius, y + radius);
}

bool Map::hasLineOfSight(
    double x1,
    double y1,
    double x2,
    double y2
) const
{
    const double dx = x2 - x1;
    const double dy = y2 - y1;

    const double distance =
        std::hypot(dx, dy);

    if (distance < 0.0001)
        return true;

    const int steps = std::max(
        1,
        static_cast<int>(
            std::ceil(distance / 0.05)
        )
    );

    for (int i = 0; i <= steps; ++i)
    {
        const double t =
            static_cast<double>(i) / steps;

        const double x = x1 + dx * t;
        const double y = y1 + dy * t;

        if (isWall(x, y))
            return false;
    }

    return true;
}
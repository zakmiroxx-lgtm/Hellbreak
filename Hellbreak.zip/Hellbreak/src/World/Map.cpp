#include "Map.h"

#include <cmath>
#include <algorithm>

Map::Map()
{
    constexpr int layout[HEIGHT][WIDTH] =
    {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,2,2,0,0,0,0,0,0,0,0,3,3,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    };

    for (int y = 0; y < HEIGHT; ++y)
    {
        for (int x = 0; x < WIDTH; ++x)
        {
            m_tiles[y * WIDTH + x] = layout[y][x];
        }
    }
}

int Map::tile(int x, int y) const
{
    if (x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT)
        return 1;

    return m_tiles[y * WIDTH + x];
}

bool Map::isWall(double x, double y) const
{
    return tile(
        static_cast<int>(std::floor(x)),
        static_cast<int>(std::floor(y))
    ) != 0;
}

bool Map::isWalkable(double x, double y, double radius) const
{
    return
        !isWall(x - radius, y - radius) &&
        !isWall(x + radius, y - radius) &&
        !isWall(x - radius, y + radius) &&
        !isWall(x + radius, y + radius);
}

bool Map::hasLineOfSight(
    double x1,
    double y1,
    double x2,
    double y2
) const
{
    const double dx = x2 - x1;
    const double dy = y2 - y1;

    const double distance = std::hypot(dx, dy);

    if (distance < 0.0001)
        return true;

    const int steps = std::max(
        1,
        static_cast<int>(std::ceil(distance / 0.05))
    );

    for (int i = 0; i <= steps; ++i)
    {
        const double t =
            static_cast<double>(i) / steps;

        const double x = x1 + dx * t;
        const double y = y1 + dy * t;

        if (isWall(x, y))
            return false;
    }

    return true;
}
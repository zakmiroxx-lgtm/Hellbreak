#define SDL_MAIN_HANDLED

#include <SDL.h>

#include "Game.h"

#include <iostream>

int main(int argc, char* argv[])
{
    (void)argc;
    (void)argv;

    SDL_SetMainReady();

    Game game;

    if (!game.initialize())
    {
        std::cerr
            << "Hellbreak initialization failed."
            << std::endl;

        return 1;
    }

    game.run();

    return 0;
}
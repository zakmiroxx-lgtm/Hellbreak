#pragma once

#include <SDL.h>

#include <memory>
#include <vector>

#include "Engine/Renderer.h"
#include "World/Map.h"
#include "World/Player.h"
#include "World/Enemy.h"

class Game
{
public:
    Game();

    ~Game();

    bool initialize();

    void run();

private:
    void processEvents();

    void update(double deltaTime);

    void render();

    void fireWeapon();

    void resetGame();

    SDL_Window* m_window = nullptr;

    SDL_Renderer* m_sdlRenderer = nullptr;

    std::unique_ptr<Renderer> m_renderer;

    Map m_map;

    Player m_player;

    std::vector<Enemy> m_enemies;

    bool m_running = false;

    bool m_gameOver = false;

    bool m_victory = false;

    bool m_fullscreen = false;
};
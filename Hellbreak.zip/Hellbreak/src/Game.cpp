#include "Game.h"

#include <algorithm>
#include <cmath>
#include <iostream>

Game::Game()
{
    resetGame();
}

Game::~Game()
{
    m_renderer.reset();

    if (m_sdlRenderer)
        SDL_DestroyRenderer(m_sdlRenderer);

    if (m_window)
        SDL_DestroyWindow(m_window);

    SDL_Quit();
}

void Game::resetGame()
{
    m_player = Player{};

    m_enemies.clear();

    m_enemies.emplace_back(8.5, 5.5);
    m_enemies.emplace_back(12.5, 7.5);
    m_enemies.emplace_back(17.5, 10.5);
    m_enemies.emplace_back(7.5, 15.5);
    m_enemies.emplace_back(18.5, 18.5);

    m_gameOver = false;
    m_victory = false;
}

bool Game::initialize()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0)
    {
        std::cerr << SDL_GetError() << std::endl;
        return false;
    }

    m_window = SDL_CreateWindow(
        "HELLBREAK: Sector Zero — Combat Edition",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        Renderer::WIDTH,
        Renderer::HEIGHT,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );

    if (!m_window)
    {
        std::cerr << SDL_GetError() << std::endl;
        return false;
    }

    m_sdlRenderer = SDL_CreateRenderer(
        m_window,
        -1,
        SDL_RENDERER_ACCELERATED |
        SDL_RENDERER_PRESENTVSYNC
    );

    if (!m_sdlRenderer)
    {
        std::cerr << SDL_GetError() << std::endl;
        return false;
    }

    SDL_RenderSetLogicalSize(
        m_sdlRenderer,
        Renderer::WIDTH,
        Renderer::HEIGHT
    );

    m_renderer = std::make_unique<Renderer>(
        m_sdlRenderer
    );

    SDL_SetRelativeMouseMode(SDL_TRUE);

    m_running = true;

    return true;
}

void Game::fireWeapon()
{
    if (m_gameOver || m_victory)
        return;

    if (!m_player.canShoot())
        return;

    m_player.shoot();

    Enemy* target = nullptr;

    double nearest = 1000.0;

    for (Enemy& enemy : m_enemies)
    {
        if (!enemy.isAlive())
            continue;

        const double dx =
            enemy.x() - m_player.x;

        const double dy =
            enemy.y() - m_player.y;

        const double distance =
            std::hypot(dx, dy);

        if (distance < 0.001)
            continue;

        double angle =
            std::atan2(dy, dx) -
            m_player.angle;

        angle = std::atan2(
            std::sin(angle),
            std::cos(angle)
        );

        const double hitRadius = 0.35;

        const double angularRadius =
            std::atan2(hitRadius, distance);

        if (std::abs(angle) > angularRadius)
            continue;

        if (!m_map.hasLineOfSight(
            m_player.x,
            m_player.y,
            enemy.x(),
            enemy.y()
        ))
        {
            continue;
        }

        if (distance < nearest)
        {
            nearest = distance;
            target = &enemy;
        }
    }

    if (target)
    {
        const bool wasAlive = target->isAlive();

        target->takeDamage(50);

        if (wasAlive && !target->isAlive())
        {
            m_player.kills++;
        }
    }
}

void Game::processEvents()
{
    SDL_Event event;

    while (SDL_PollEvent(&event))
    {
        if (event.type == SDL_QUIT)
        {
            m_running = false;
        }

        if (event.type == SDL_KEYDOWN)
        {
            const SDL_Keycode key =
                event.key.keysym.sym;

            if (key == SDLK_ESCAPE)
            {
                m_running = false;
            }

            if (key == SDLK_F11 && event.key.repeat == 0)
            {
                m_fullscreen = !m_fullscreen;

                SDL_SetWindowFullscreen(
                    m_window,
                    m_fullscreen
                        ? SDL_WINDOW_FULLSCREEN_DESKTOP
                        : 0
                );
            }

            if (key == SDLK_r && (m_gameOver || m_victory))
            {
                resetGame();
            }
        }

        if (event.type == SDL_MOUSEMOTION)
        {
            if (!m_gameOver && !m_victory)
            {
                m_player.rotate(
                    event.motion.xrel *
                    m_player.mouseSensitivity
                );
            }
        }

        if (event.type == SDL_MOUSEBUTTONDOWN)
        {
            if (event.button.button == SDL_BUTTON_LEFT)
            {
                fireWeapon();
            }
        }
    }
}

void Game::update(double deltaTime)
{
    if (m_gameOver || m_victory)
        return;

    m_player.update(deltaTime);

    const Uint8* keys =
        SDL_GetKeyboardState(nullptr);

    double forward = 0.0;
    double strafe = 0.0;

    if (keys[SDL_SCANCODE_W])
        forward += 1.0;

    if (keys[SDL_SCANCODE_S])
        forward -= 1.0;

    if (keys[SDL_SCANCODE_A])
        strafe -= 1.0;

    if (keys[SDL_SCANCODE_D])
        strafe += 1.0;

    const bool sprint =
        keys[SDL_SCANCODE_LSHIFT] ||
        keys[SDL_SCANCODE_RSHIFT];

    m_player.moveSpeed =
        sprint ? 5.8 : 3.5;

    m_player.move(
        m_map,
        forward,
        strafe,
        deltaTime
    );

    for (Enemy& enemy : m_enemies)
    {
        enemy.update(
            m_map,
            m_player,
            deltaTime
        );
    }

    if (!m_player.isAlive())
    {
        m_gameOver = true;
    }

    bool allDead = true;

    for (const Enemy& enemy : m_enemies)
    {
        if (enemy.isAlive())
        {
            allDead = false;
            break;
        }
    }

    if (allDead)
    {
        m_victory = true;
    }
}

void Game::render()
{
    m_renderer->render(
        m_map,
        m_player,
        m_enemies,
        m_gameOver,
        m_victory
    );
}

void Game::run()
{
    Uint64 previous =
        SDL_GetPerformanceCounter();

    const double frequency =
        static_cast<double>(
            SDL_GetPerformanceFrequency()
        );

    while (m_running)
    {
        const Uint64 current =
            SDL_GetPerformanceCounter();

        double deltaTime =
            (current - previous) / frequency;

        previous = current;

        deltaTime = std::clamp(
            deltaTime,
            0.0,
            0.05
        );

        processEvents();
        update(deltaTime);
        render();
    }
}
# Third-Party Components

## SDL2

Project:
Simple DirectMedia Layer

Website:
https://www.libsdl.org/

Repository:
https://github.com/libsdl-org/SDL

Version:
2.30.12

License:
zlib License

Purpose:

- Window creation
- Input handling
- Rendering
- Event processing

SDL2 is downloaded from its official
repository during the CMake build.

## CMake

Website:
https://cmake.org/

Purpose:
Build configuration.

## Assets

Hellbreak 0.1 does not contain
third-party textures, music, models,
sound effects or fonts.

The graphics are generated
programmatically.

## Intellectual Property

Hellbreak is an independent
retro first-person shooter.

No third-party commercial game
assets are intentionally included.
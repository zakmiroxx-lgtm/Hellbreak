# HELLBREAK: Sector Zero

Version: 0.1.0

An original retro first-person shooter
written in C++20 using SDL2.

## Features

- First-person raycasting engine
- Procedural wall textures
- Mouse look
- WASD movement
- Sprint
- Collision detection
- Minimap
- Crosshair
- Fullscreen mode

## Controls

W - Move forward
S - Move backward
A - Strafe left
D - Strafe right

Mouse - Look around
Shift - Sprint
F11 - Toggle fullscreen
Escape - Exit

## Requirements

Windows 10/11

For building:

- CMake 3.21+
- C++20 compiler
- Git
- Internet connection

SDL2 is downloaded automatically
during CMake configuration.

## Build

cmake -S . -B build

cmake --build build --config Release

## License

MIT License.

See LICENSE.

## Third-party components

See THIRD_PARTY.md.